from backend.database.entry import ParkingEntry
from backend.database.registration_plate import RegistrationPlate
from backend.database.user import User
from backend.database.base_class import BaseSql
