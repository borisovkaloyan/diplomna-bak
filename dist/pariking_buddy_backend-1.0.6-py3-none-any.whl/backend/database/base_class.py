from sqlalchemy.orm import DeclarativeBase

class BaseSql(DeclarativeBase):
    pass
